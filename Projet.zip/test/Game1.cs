﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using test.modules;

namespace test
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Panier panier;
        private List<Fruit> fruitList;
        private int maxFruitCount;
        private Vector2 screenSize;
        public static Random random = new Random();
        private SpriteFont PointFont;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            screenSize = new Vector2(_graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            panier = new Panier(screenSize);
            fruitList = new List<Fruit>();
        }
        private void AddNewFruit()
        {
            if (fruitList.Count <= maxFruitCount)
            {
                Fruit newFruit = new(screenSize , fruitList);
                newFruit.Initialize();
                newFruit.LoadContent(Content, GraphicsDevice) ;
                fruitList.Add(newFruit);
            }
        }
        protected override void Initialize()
        {
            maxFruitCount = random.Next(8,15);
            panier.Initialize();
            for (int i = 0; i < fruitList.Count; i++)
                fruitList[i].Initialize();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            panier.LoadContent(Content, GraphicsDevice);
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            for (int i = 0; i < fruitList.Count; i++)
                fruitList[i].LoadContent(Content, GraphicsDevice);
            PointFont = Content.Load<SpriteFont>("Font/fontTest");
            // TODO: use this.Content to load your game content here
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            AddNewFruit();
            for (int i = 0; i < fruitList.Count; i++)
                fruitList[i].Update();

            panier.Update();
            panier.CreateColision(fruitList);
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();
            for (int i = 0; i < fruitList.Count; i++)
                fruitList[i].Draw(_spriteBatch);
            panier.Draw(_spriteBatch);
            _spriteBatch.DrawString(PointFont, "Point: " + panier.exp, new Vector2(100, 20), Color.DarkRed);
            _spriteBatch.End();
            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
