﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Media;

namespace test.modules
{
    internal class Audio
    {
        public static void PlaySound(Song song)
        {
            if (MediaPlayer.State != MediaState.Playing)
                MediaPlayer.Stop();
           
            if (song != null )
            {
                MediaPlayer.Play(song);
                MediaPlayer.IsRepeating = false;
            }
        }
    }
}
