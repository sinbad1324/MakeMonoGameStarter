﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace test.modules
{
    public interface GlobalI
    {
        void Update();
        void Initialize();
        void Draw(SpriteBatch target);
        void LoadContent( ContentManager content,GraphicsDevice device);

    }
}
