﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace test.modules
{
    enum Fruits
    {
        Pomme,
        Banane,
        Orange,
        Fraise,
        Raisin
    }
    public class Fruit : GlobalI
    {
        //Public
        public static  Random random = new Random();
        public readonly int exp = random.Next(20,50);
        //private
        private Color color ;
        private readonly int speed = random.Next(1, 3);
        private Texture2D texture ;
        private Vector2 StartPosition;
        private Vector2 screenSize;
        private Rectangle rectangle;
        private List<Fruit>  parentList;
        
        // PUBLIC METHODES
        public Fruit(Vector2 screenSize , List<Fruit> parentList) {
            this.screenSize = screenSize;
            this.parentList = parentList;
        }

        public void Initialize() {
            StartPosition = new Vector2(random.Next(1, (int)screenSize.X) , -100);
            rectangle = new Rectangle((int)StartPosition.X , (int)StartPosition.Y ,50,50);
        }
        public void Update() {
            StartPosition += new Vector2(0,speed);
            rectangle.Location = StartPosition.ToPoint();
            if ((50+StartPosition.Y)>screenSize.Y)
            {
                parentList.Remove(this);
            }
        }
        public void Draw(SpriteBatch target) {
            target.Draw(texture, rectangle, Color.White);
        }
        public void LoadContent(ContentManager content, GraphicsDevice device) {
            string fruitName = ((Fruits)random.Next(0, 5)).ToString();
            texture= content.Load<Texture2D>( fruitName);
        }
        public Rectangle GetRectangle()
        {
            return rectangle;  
        }

    }
}
