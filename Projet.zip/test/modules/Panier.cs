﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace test.modules
{
    public class Panier
    {
       
        //Public
        public static Random random = new Random();
        //private
        private Color color;
        public  int exp = 0;
        private readonly int speed = random.Next(5, 10);
        private Texture2D texture;
        private Vector2 screenSize;
        private Rectangle rectangle;
        private KeyboardState keyboardState;
        private MouseState mouseState;
        private SpriteFont fontTest;
        private Song song;
        // PUBLIC METHODES
        public Panier(Vector2 screenSize) { this.screenSize = screenSize; }
        public void Initialize()
        {
            rectangle = new Rectangle(random.Next(0, (int)screenSize.X), random.Next(0,(int)screenSize.Y), 100, 100);
        }
        public void Update()
        {
            keyboardState = Keyboard.GetState();
            mouseState = Mouse.GetState();

            if (keyboardState.IsKeyDown(Keys.W))
            {
                rectangle.Location += (new Vector2(0, -1) * speed).ToPoint();

            }
            else if (keyboardState.IsKeyDown(Keys.S))
            {
                rectangle.Location += (new Vector2(0, 1) * speed).ToPoint();
            }

            if (keyboardState.IsKeyDown(Keys.A))
            {
                rectangle.Location += (new Vector2(-1, 0) * speed).ToPoint();

            }
            else if (keyboardState.IsKeyDown(Keys.D))
            {
                rectangle.Location += (new Vector2(1, 0) * speed).ToPoint();
            }
        }
        public void Draw(SpriteBatch target)
        {
            target.Draw(texture, rectangle, Color.White);
            target.DrawString(fontTest, "Player", rectangle.Location.ToVector2() + new Vector2(30, -30), Color.Black);
        }
        public void LoadContent(ContentManager content, GraphicsDevice device)
        {
            texture = content.Load<Texture2D>("panier");
            fontTest = content.Load<SpriteFont>("Font/fontTest");
            song = content.Load<Song>("Sound/bom");
        }
        public Rectangle GetRectangle()
        {
            return rectangle;
        }
        public void CreateColision(List<Fruit> fruits)
        {
            foreach (var item in new List<Fruit>(fruits))
            {
                if (item == null) continue;
                if (rectangle.Contains(item.GetRectangle()))
                {
                    fruits.Remove(item);
                    Audio.PlaySound(song);
                    exp += item.exp;
                }
            }
        }
    }
}
