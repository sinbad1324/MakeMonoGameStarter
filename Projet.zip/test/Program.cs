﻿
using var game = new test.Game1();
game.Run();
